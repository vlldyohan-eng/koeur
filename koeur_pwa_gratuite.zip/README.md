# Koeur PWA — démonstration gratuite

Cette version est une PWA statique : elle peut être installée sur Android/iPhone depuis un navigateur compatible.

Elle ne collecte pas de compte réel et utilise uniquement localStorage pour la démonstration.

Pour une vraie application de rencontre commerciale, ne pas utiliser GitHub Pages comme backend : GitHub indique que Pages n'est pas destiné à l'hébergement d'un SaaS commercial ou aux transactions sensibles. Il faut un backend sécurisé séparé.
